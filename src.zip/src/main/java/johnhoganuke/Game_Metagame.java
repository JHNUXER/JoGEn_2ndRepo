package johnhoganuke;

public class Game_Metagame extends Game; {
  name = "Metagame";
}
