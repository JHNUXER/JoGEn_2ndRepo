public class Pos {
  int x;
  int y;
  int z;
}
