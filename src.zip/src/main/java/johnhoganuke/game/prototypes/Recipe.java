package game.prototypes;

import game.prototypes.RecipeType;
import game.data.AllRecipes;
import game.prototypes.ItemInt;

public class Recipe {
  String name;
  
  ItemInt [] requires;
  ItemInt [] produces;
  
  RecipeType type = CRAFTING;
  
  void create(String n, ItemInt [] r, ItemInt p, RecipeType t) {
    name = n;
    requires[] = r[];
    produces[] = p[];
    type = t;
  }
  
  void makeSmelting(int rt, int time, ItemIntInt [] rq) {
    this.type = SMELTING;
    int time;
    ItemIntInt [] requires = rq;            // needs a requiredTemperature variable;
  }
  
  Recipe getAll(RecipeType t) {
    Recipe [] g = {};
    for (int i = 0, i == (AllRecipes.length), i++) {
      if (AllRecipes[i].type == t || t == REC_ALL) {
        if (i == 0) { g[0] = AllRecipes[i]; }
        else { g[g.length] = AllRecipes[i]; }
      }
    }
    return g;
  }
}
