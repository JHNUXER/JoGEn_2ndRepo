public class Character extends Gobject implements Alive {
  String name;
  
  Ispace inventory;
  Aspace armor;
  Ispace hands;
  
  public class Attributes {
    int agility;
    int dexterity;
    int flexability;
    int height;
    int strength;
    int weight;
  }
  
  public static int main(String args) {
    this.life = (this.life > this.maxLife)?this.maxLife:this.life;
    this.dead = (this.life < 1)?true:false;
  }
}
