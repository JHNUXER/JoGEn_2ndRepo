public class Character_Kazuto {
  name = "Kazuto";
  life = 100;
  maxLife = 100;
  

}
