public class Tool_Wrench {
  durability = 100;
  int maxDurability = 100;
  
  boolean use(Machine on, boolean shift, boolean ctrl) {
    on.wrenchAction(shift, crtl);
  }
}
