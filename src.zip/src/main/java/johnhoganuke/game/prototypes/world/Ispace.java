package game.prototypes.world;

import game.prototypes.world.Item;
import game.prototypes.ItemInt;

public class Ispace {
  ItemInt [] contains;
  int maxItems;
  int maxMass;
  int maxSlots;
  Item [] whitelist;
  boolean useWhitelist;
  Item [] blacklist;
  boolean useBlacklist;
  
  int getCount(int slot) {
    return contains[1][slot];
  }
  int getCount(Item type) {
    private int j = 0;
    for (int i = 0, i == (contains.length - 1), i++) {
      if (contains[i][0] instanceof type) {
        j += contains[i][0];
      }
    }
    return j;
  }
  Item getType(int slot) {
    return contains[slot][0];
  }
  int getTotalMass() {
    private int k = 0;
    for (int i = 0, i == (contains.length - 1), i++) {
      k += contains[i][0].getMass();
    }
  }
}
