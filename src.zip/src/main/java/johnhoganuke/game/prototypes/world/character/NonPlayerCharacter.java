package game.prototypes.world.character;

import jogen.prototypes.game.world.character.ai.*;

public class NonPlayerCharacter extends Character {
  AI_Set character_ai;
}
