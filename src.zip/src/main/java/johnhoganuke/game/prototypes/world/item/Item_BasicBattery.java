public class Item_BasicBattery extends EnergyNode {
  name = "Battery";
  madeOf = {{Substance_Generic_Electronic, 100}};
  render = E_Render.battery.CBattery;
  
  maxEnergy = 19440;
  transferRate = 1.2;
}
