package game.prototypes.world;

import game.prototypes.world.substance;
import game.prototypes.jogen.Render_Class;

public class Item {
  String name;
  Substance [] madeOf;
  Render_Class render;
}
