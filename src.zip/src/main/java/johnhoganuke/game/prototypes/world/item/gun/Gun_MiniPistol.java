public class Gun_MiniPistol {
  rateOfFire = 999999999;
  recoil = 0;
  knockback = 999999999;
  projectileType = Projectile_80CaliberBullet;
  projectileType.isExplosive = true;
  projectileType.Explosive.isNuclear = true;
}
