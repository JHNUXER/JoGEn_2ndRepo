package game.prototypes.world;

import game.prototypes.world.Nobject;
import game.prototypes.world.Item;
import japi.j1.prototypes.Pos;

public class Iobject extends Nobject {
  String name;
  Pos position;
  Item i;
  
  void create(Item it, Pos p) {
    name = "Pick up " + i.name;
    position = p;
    i = it;
  }
}
