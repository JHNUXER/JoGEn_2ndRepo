package game.prototypes.world;

import game.prototypes.world.Gobject;
import game.prototypes.world.Ispace;

public class Container extends Gobject {
  Ispace inventory;
}
