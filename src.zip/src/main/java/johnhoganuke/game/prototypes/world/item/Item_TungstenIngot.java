package game.prototypes.world.item;

import game.prototypes.world.Item;
import game.data.E_Render;

public class Item_TungstenIngot extends Item {
  name = "Tungsten Ingot";
  madeOf = {{Substance_Tungsten, 100}};
  render = E_Render.ingots.TungstenIngot;
}
