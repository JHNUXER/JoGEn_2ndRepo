public class Gobject extends Item, Nobject {
  Iobject toIobject() {
    private Iobject k = new Iobject(this.name, this.madeOf[], this.render, this.position);
    return k;
  }
  Projectile toProjectile(int iv, int mv, int a) {
    private Projectile p = new Projectile(this.name, this.madeOf[], this.render, this.position, iv, mv, a);
    return p;
  }
}
