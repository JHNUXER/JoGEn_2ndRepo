public class Sword_DewaynesSword {
  name = "Dewayne\'s Sword";
  dmg = 0.1;
  knockback = -3;
  render = E_Render.basic_sword.cardboardBlade;
  lightning = true;
  
  void convert() {
    this = Sword_DewaynesSword_LightningVersion;
  }
  
  public class Sword_DewaynesSword_LightningVersion {
    name = "Dewayne\'s Sword";
    long dmg = 18446743999999999999;
      long knockBack = 18446743999999999999;
  
  public class Strike {       // Because WHY THE FUCK NOT?!?!?!?!?!?!!?!??!!?!?!?!?!
    long distance;
    long force;
    long knowckback;
    long velocity;
    long dmg;
    
    long iteration;
    boolean explosive;
    
    void create(int r, int f, int k, int v, int d, int i, boolean e) {  // g
      distance = r;
      force = f;
      knockback = k;
      velocity = v;
      dmg = d;
      iteration = i;
      explosive = e;
    }
  }
  
  Strike swordStrike = new Strike(18446743999999999999, 18446743999999999999, 18446743999999999999, 18446743999999999999, 18446743999999999999, 30, false);
  Lamp swordGlow = new Lamp(10, {255,0,0,100});  // (strength, color)
  }
}
