public class Character_Dewayne extends Character {
  name = "Dewayne";
  
  Attrib {
    strenght = 99999999;
  }
}
