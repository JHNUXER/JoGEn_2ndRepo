package game.prototypes.world.energy;

public class EnergyProducer extends EnergyNode {
  int productionRate;
  GeneratorType generationType;
  
  public enum GeneratorType {
    THERMAL,
    SOLAR,
    KINETIC,
    AERODYNAMIC,
  }
}
