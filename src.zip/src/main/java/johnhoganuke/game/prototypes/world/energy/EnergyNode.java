package game.prototypes.world.energy;

public class EnergyNode {
  int energy;
  int maxEnergy;
  float inputRate;              // transferRate's are measured in Volts
  float outputRate;
  
  EnergyNode [] connectedInputs;
  EnergyNode [] connectedOutputs;
}
