public class Nobject {
  String name;
  Render_Class render;
}
