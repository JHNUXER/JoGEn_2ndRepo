package game.prototypes.world.machine;

import game.prototypes.world.Machine;
import game.prototypes.world.energy.EnergyProducer;
import game.prototypes.world.Ispace;

public class Machine_SmallReactor extends Machine, EnergyProducer {
  name = "Small Nuclear Reactor";
  madeOf = {{Substance_Steel, 100}};
  render = E_Render.nuclear_reactor_small;
  
  generationType = NUCLEAR;
  productionRate = 300000000000;      // 300GigaWatts (might lower this, not sure yet)
  transferRate = 300000000000;        // Transfers as fast as it produces, otherwise having such large production
                                      // would be entirely pointless
  maxEnergy = 3000000000000;          // can store 10x as much energy for buffering purposes.
  ItemSpace fuel;
  fuel.maxSlots = 1;
  fuel.useWhitelist = true;
  fuel.whitelist = {Item_UraniumIngot};
  
  int fuelConsumption = 2;
  
  boolean consume() {
    private int fc = fuel.contains[0][1];
    fuel.contains[0][1] = (fuel.contains[0][1] >= fuelConsumption)?fuel.contains[0][1] - fuelConsumption;
    return (fc > fuel.contains[0][1])?true:false;
  }
  boolean produce() {
    private int e = this.energy;
    this.energy = ((this.maxEnergy - this.energy) >= productionRate)?this.energy + productionRate;
    return (e < this.energy)?true:false;
  }
  
  public static int main(String [] args) {
    if (consume()) {
      produce();
    }
    
    return 0;
  }
}
