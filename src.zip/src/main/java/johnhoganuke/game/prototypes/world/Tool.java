package game.prototypes.world;

public abstract class Tool {
  int durability;
  
  bool use(Gobject on) {
    return false;
  }
}
