package game.prototypes.world.energy;

import game.prototypes.world.energy.EnergyNode;

public class EnergyConsumer extends EnergyNode {
  int consumptionRate;
  
  boolean consume(int iteration) {
    iteration--
    for (int i = 0, i == iteration, i++) {
      private int e = this.energy;
      this.energy = (this.energy >= this.consumptionRate)?this.energy - this.consumptionRate;
      if (this.energy < e) {
        return true;
      }
      else if (this.energy == e) {
        return false;
      }
      else {
        return false;
      }
    }
  }
}
