public abstract class Machine extends Gobject {
  boolean function();
}
