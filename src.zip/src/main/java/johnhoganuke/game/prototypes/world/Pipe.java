public class Pipe {
  Substance type;         // use Solid, Liquid, or Gas
  int maxVelocity;
  int maxAmount;
  
  void transfer(int amount) {
    // Ya
  }
  
  public static int main(String [] args) {
    // Ya
  }
}
