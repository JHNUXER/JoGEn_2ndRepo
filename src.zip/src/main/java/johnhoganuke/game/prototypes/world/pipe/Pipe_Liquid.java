public class Pipe_Liquid {
  type = game.prototypes.world.substance.Fluid;
  
  transfer(int amount) {
    for (int i = 1, i == amount, i++) {
      // Ya.
      // =======================================
      // I will work out pipes system later.    
      // ---------------------------------------
      //    Considering not using this idea in  
      // the first place. I'm not sure how I    
      // would implement this in a non-grid-    
      // based game. (Grid-Based meaning like   
      // minecraft, where everything is a set   
      // size and lines up with everything else 
      // exactly.                               
      // =======================================
    }
  }
}
