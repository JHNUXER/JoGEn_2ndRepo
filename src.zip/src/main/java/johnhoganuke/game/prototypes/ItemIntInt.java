package game.prototypes;

import game.prototypes.ItemInt;

public class ItemIntInt extends ItemInt {
  int ii;
}
