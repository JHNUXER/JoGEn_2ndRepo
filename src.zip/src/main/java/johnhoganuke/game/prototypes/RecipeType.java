package game.prototypes;

public enum RecipeType {
  CRAFTING,
  SMELTING,
  WIRE_MILL,
  PRESS;
}
