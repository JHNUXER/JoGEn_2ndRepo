public class World implements Named {
  Gobject [] objects;
  Machine [] machines;
  Character [] characters;
  Item [] items;
  Iobject [] iobjects;
  
  void load(String file) {
    // Ya
  }
  void save(String file) {
    // Ya
  }
  void erase(String file) {
    // Ya
  }
}
