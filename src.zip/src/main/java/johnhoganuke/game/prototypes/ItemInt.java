package johnhoganuke.game.prototypes;

import game.prototypes.world.Item;

public class ItemInt {
  Item i;
  int c;
}
