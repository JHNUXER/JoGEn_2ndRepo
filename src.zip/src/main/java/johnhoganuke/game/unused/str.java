package game.unused;

public class str {        // I figured out how to make my own String class.
  char [] s;
}
