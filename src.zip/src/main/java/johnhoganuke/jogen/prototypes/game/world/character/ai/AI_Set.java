public class AI_Set {
  String ai_name;
  int hostility;
  
  public class Attrib {
    public class Aphysical {
      int agressivity;
      // will finish later.
    }
    public class Physical {
      int agility;
      int flexability;
      int speed;
      int stamina;
      int strength;
    }
  }
  
  // Ya
}
