package jogen.physics.attrib;

import global.prototypes.Pos;

public interface Physical {
  Pos velocity;
}
